import React, { useEffect, useState } from "react"
import { MeiliSearch } from "meilisearch"

const client = new MeiliSearch({
  host: "http://89.169.161.5:7700",
  apiKey: "supersecretkey"
})

export default function App() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState([])

  useEffect(() => {
    if (!query) return
    client.index("products").search(query).then(res => setResults(res.hits))
  }, [query])

  return (
    <div style={{ padding: "2rem" }}>
      <h1>Поиск по товарам</h1>
      <input
        placeholder="Введите запрос"
        value={query}
        onChange={e => setQuery(e.target.value)}
        style={{ padding: "0.5rem", width: "300px" }}
      />
      <ul>
        {results.map(item => (
          <li key={item.id}>
            <strong>{item.title}</strong> — {item.price} ₽
            <div style={{ fontSize: "0.9rem", color: "#555" }}>
              {item.brand} / {item.category} / {item.size}
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
